<head>
<link href="style.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src ="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<!--  footer section start -->
<div id="footer" >

<p>English (UK),India,Al Khawr,Al Udeid Air Base,Hamad International,Australia.,Bahamas.<p>

<ul id="social" >
  <!-- Basic Share Links -->

<!-- Twitter (url, text, @mention) -->
<i style="font-size:15px" class="fa btn btn-danger">&#xf173;</i><a href="http://twitter.com/share?url=<URL>&text=<TEXT>via=<USERNAME>">
<!--    Twitter-->
</a>

<!-- Google Plus (url) -->
<i style="font-size:15px" class="fa btn btn-danger">&#xf0d5;</i><a href="https://plus.google.com/share?url=<URL>">
  <!--  Google Plus -->
</a>

<!-- Facebook (url) -->
<i style="font-size:15px" class="fa btn btn-danger">&#xf230;</i><a href="http://www.facebook.com/sharer/sharer.php?u=<URL>">
  <!--  Facebook-->
</a>

<!-- StumbleUpon (url, title) -->
<i style="font-size:15px" class="fa btn btn-danger">&#xf287;</i><a href="http://www.stumbleupon.com/submit?url=<URL>&title=<TITLE>">
  <!--  StumbleUpon-->
</a>

<!-- Reddit (url, title) -->
<i style="font-size:15px" class="fa btn btn-danger">&#xf1a4;</i><a href="http://reddit.com/submit?url=<URL>&title=<TITLE>">
   <!-- Reddit -->
</a>

<!-- LinkedIn (url, title, summary, source url) -->
<i style="font-size:15px" class="fa btn btn-danger">&#xf1bd;</i><a href="http://www.linkedin.com/shareArticle?url=<URL>&title=<TITLE>&summary=<SUMMARY>&source=<SOURCE_URL>">
  <!--  LinkedIn-->
</a>

<!-- Email (subject, body) -->

</ul>
</div>
<!--  footer section End -->