<?php
session_start();
//include "connection.php";
require('connection.php');
error_reporting(1);
ini_set('error_reporting', E_ALL);
if(isset($_POST['firstname'])) 
{
	$firstname =$_POST['name3'];
	
     $status=1;
   

      $z="select * from register where name='$name3'";
      $chk=$conn->query($z);
    if($r=$chk->fetch_assoc())
  {
    $return_data["error_existemail"]="User email Already Exist!!!";
    echo json_encode($return_data);
    $status=0;
  }
   
 else
{
