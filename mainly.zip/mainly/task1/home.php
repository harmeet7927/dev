<head>
<link href="style.css" type="text/css" rel="stylesheet"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src ="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style type="text/css">
	.modal-header {
    padding:9px 15px;
    border-bottom:1px solid #eee;
    background-color: #0480be;
    -webkit-border-top-left-radius: 5px;
    -webkit-border-top-right-radius: 5px;
    -moz-border-radius-topleft: 5px;
    -moz-border-radius-topright: 5px;
     border-top-left-radius: 5px;
     border-top-right-radius: 5px;
 }


</style>

<body>
<div id="headcontainer">
<!-- modal for view-->
<div class="container">
   <!-- Modal -->
  <div class="modal fade" id="myModal5" role="dialog">
    <div class="modal-dialog">
          <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        
        <div id="viewform"></div>
        
      </div>
    </div>
      
    </div>
  </div>
  
</div>


<!-- modal for view End-->




<!-- modal for Edit action start-->
<div class="container">
   <!-- Modal -->
  <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
          <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <div id="editform"></div>
          
     
      </div>
    </div>
      
    </div>
  </div>
  
</div>


<!-- modal for Edit action start-->
	<!-- title section start-->
<!-- <div id="container"> -->
 <div id="container">
   <div id="sitename"><a href="">Gallery</a> </div>
    
  <font size="5"> <p  id="num" style="color:white;" >
<b><br>   </p></font>

 </div>
<!--</div>-->
<!-- title section End-->
</br>
<a href="" name="btn" class="btn btn-danger " data-toggle="modal" data-target="#myModal">ADD CONTACT</a>




  <!--  modal containder start -->
<div class="container">
  <!-- Trigger the modal with a button -->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
        <div class="modal-body">
          <p>Some text in the modal.</p>
      <form action=" " id="form3" method="post">
			<div id="div2">
			<h1>Create contact List</h1>
			<br>		
			<li><input type="text" id="name3" name="name3" placeholder="Name" ></li>
			<!--<li><input type="text" id="email3" name="email3" placeholder=" email address"></li>
			//<li><input type="ph" id="tel" name="ph" placeholder="Ph.no3"></li>-->
			 <li><input type="submit" name="subconatct" id="subconatct" value="submit"></li>
		</div>
	</form>
 </div>
 </div>
      
</div>
  </div>
  
</div>
<!--  modal containder End -->
 







<!--  body section End -->
<!-- footer file -->
<?php include "footer.php" ?>

<!-- footer file End-->


</div>
<!--  main div close -->

</body>

<!--  script section start -->
<script>
$(document).ready(function(){
  
//Edit section start
  $('.editdata').on('click',function(){ 
  var reqtypedb = 'editdb';
     var id =$(this).attr('id');
  $.ajax({
  dataType: 'json',
    type: 'POST',
    data: 'reqdb='+reqtypedb+'&id='+id,
    url: 'ajax.php',
    success: function(data){
     var output = data.formedit;
        $('#editform').html('').append(output);      
  }
  });
  });
//Edit section End


/*Delete Data coding
$('.delete').on('click',function(e){ 
   e.preventDefault();
   
      var delete1 = 'delete';
      var id =$(this).attr('id');
    
    var datastring = 'delete='+delete1+'&id='+id;
      $.ajax({
      dataType: 'json',
        type: 'POST',
        data: datastring,
        url: 'ajax.php',
        success: function(data){
        alert('data delete successfully');    
  }
  });
  });*/
//End delete Coding 

  });
</script>
<!--  script section End -->
</html>
