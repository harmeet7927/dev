<form method="post" action="location.php">
	Address : <input type="text" value="" name="address" /><br/>
	City :<input type="text" value="" name="city" /><br/>
	State : <input type="text" value="" name="state" /><br/>
	Country : <input type="text" value="" name="country" /><br/>
	Zip code :<input type="text" value="" name="zip" /><br/>
	<input type="submit" name="submit" value="Find Location" />
</form>