<script type="text/javascript">
curl https://connect.stripe.com/oauth/token \
   -d client_secret=sk_test_f4L11ATEiU50sHpTKrh8VoUU \
   -d code="{AUTHORIZATION_CODE}" \
   -d grant_type=authorization_code

</script>