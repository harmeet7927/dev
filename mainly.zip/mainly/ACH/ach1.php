
<!DOCTYPE html>
<html lang="en">

<head>                
  <title>Plaid Demo Application</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="https://cloud.typography.com/6954312/686646/css/fonts.css"/>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/8.6/styles/default.min.css">
  <link rel="stylesheet" type="text/css" href="styles/style.css">
  <link rel="shortcut icon" href="favicon.ico"/>
  <script type="text/javascript" src="https://cdn.plaid.com/js/jquery-2.1.3.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/8.6/highlight.min.js"></script>
 <!--  <script>hljs.initHighlightingOnLoad();</script> -->
</head>
<body>


<div class="container">
  <div class="explainer">
    <form class="launchform" id="launchform" action="">
      <div class="toggle product">
        <div class="radiobutton">
          <input type="radio" name="product" id="auth" value="auth" checked>
          <label for="auth"><span></span>Plaid Auth</label>
        </div>
        <div class="radiobutton">
          <input type="radio" name="product" id="transactions" value="transactions">
          <label for="transactions"><span></span>Plaid Transactions</label>
        </div>
      </div>

      <div class="launchbutton">
        <input type="submit" class="button-primary" id="button" onsubmit="openLink(form)" value="Link Account with Plaid">
       
      </div>
    </form>
  </div> 
</div>


<script src="https://cdn.plaid.com/link/v2/stable/link-initialize.js"></script>
<script type="text/javascript">
  'use strict';

  var currentlySelectedProduct;
  $(document).ready(function() {
    $('#launchform').on('submit', function(e) {
      e.preventDefault();

      var mode = 'sandbox';
      var product = $('input[name=product]:checked', this).val();

      currentlySelectedProduct = product;

      // Open Link
      handlers[mode][product].open();
    });

/*    $('#open-code-link').on('click', function(e) {
      e.preventDefault();

      $('#code-section').toggle()
    })*/
  });

  var createPlaidHandlerForProduct = function(key, product) {
    if (product !== 'transactions' && product !== 'auth') {
      throw new Error('Invalid product');
    }

    return Plaid.create({
      clientName: 'Plaid Demo',
      env: 'sandbox',
      product: product,
      key: key,
      onSuccess: function(token) {
        window.location = '/ACH/accounts.php?public_token=' + token + '&product=' + currentlySelectedProduct ;
      },
    });
  };

  var handlers = {
    sandbox: {
      auth: createPlaidHandlerForProduct('a9536dd5db33d7bbbdb096c56a1593', 'auth'),
      transactions: createPlaidHandlerForProduct('ca_D1thSbm0pYpHgfhbuXmqnUG8qdMtXdup', 'transactions'),
    },
  };
</script>
</body>
</html>
