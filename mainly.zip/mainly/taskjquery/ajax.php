<?php
  include("connection.php");
  if(isset($_POST['name'])) 
		{
			$name =$_POST['name'];
         $lastname=  $_POST["lastname"];
         $address=   $_POST["address"];
         $city=      $_POST["city"];
         $state=     $_POST["state"];
         $zip=       $_POST["zip"];
         $title=     $_POST["title"];
         $company=   $_POST["company"];
         $ph=        $_POST["ph"];
         $email=     $_POST["email"];
         $website=   $_POST["website"];
         $file_tmp=$_FILES["upload_file"]["tmp_name"];
          $file_name=$_FILES["upload_file"]["name"];


      $z="select * from register where email='$email'";
      $chk=$conn->query($z);
     
      if($r=$chk->fetch_assoc())
      {
	        $return_data["success"]="User email Already Exist!!!";
	        echo json_encode($return_data);
   
      }
      else
      {
		$targetfolder = "images/";
		$targetfolder = $targetfolder . basename( $_FILES['upload_file']['name']) ;
		 if(move_uploaded_file($_FILES['upload_file']['tmp_name'], $targetfolder))
		 
		{
			 $sql="INSERT INTO register (name, lastname,address, city, state, zip,title,company, ph,email,website,image)VALUES('$name', '$lastname','$address',' $city','$state','$zip','$title','$company','$ph','$email','$website','$file_name')";

	          if(mysqli_query($conn, $sql)) 
	           {
		          	$return_data["success"]="New record created successfully!";
		            echo json_encode($return_data);
	            
	           } 
	    
	        	/*echo "The file ". basename( $_FILES['upload_file']['name']). " is uploaded";*/
		 
		}
		 
		else
		 {
		 
	    	echo "Problem uploading file";	
         }
   }
 }
?>