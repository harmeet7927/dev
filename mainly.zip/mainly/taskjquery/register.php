
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src ="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="style.css">

<!-- <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.js"> -->
  <style type="text/css">
    #form .error {
    color: red;
     }
  </style>
</head>
<body>

<div class="container">
  <h2 align="center">Register Form</h2>
  <!-- Trigger the modal with a button -->
   <p align="center"><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" >Open form</button></p>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" align="center">Register Form</h4>
             <div id="done" align="center" style="display: none;" ></div>
        </div>
        <div class="modal-body">


         <form action=" " id="form" method="POST" enctype="multipart/form-data">  
                 <div class="form-group">
                            <label>Image</label>
                             <input type="file" id="upload_file" name="upload_file" />
                        </div>          
                     <div class="col-sm-12">
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label>First Name</label>
                                <input type="text" id="name" name="name" placeholder="Enter First Name Here.." class="form-control">
                            </div>
                            <div class="col-sm-6 form-group">
                                <label>Last Name</label>
                                <input type="text" id="lastname" name="lastname" placeholder="Enter Last Name Here.." class="form-control">
                            </div>
                        </div>                  
                        <div class="form-group">
                            <label>Address</label>
                            <textarea placeholder="Enter Address Here.." rows="3"  id="address" name="address" class="form-control"></textarea>
                        </div>  
                        <div class="row">
                            <div class="col-sm-4 form-group">
                                <label>City</label>
                                <input type="text" placeholder="Enter City Name Here.." id="city" name="city" class="form-control">
                            </div>  
                            <div class="col-sm-4 form-group">
                                <label>State</label>
                                <input type="text" placeholder="Enter State Name Here.." id="state" name="state" class="form-control">
                            </div>  
                            <div class="col-sm-4 form-group">
                                <label>Zip</label>
                                <input type="text" placeholder="Enter Zip Code Here.." id ="zip" name="zip" class="form-control">
                            </div>      
                        </div>
                        <div class="row">
                            <div class="col-sm-6 form-group">
                                <label>Title</label>
                                <input type="text" placeholder="Enter Designation Here.." id="title" name="title" class="form-control">
                            </div>      
                            <div class="col-sm-6 form-group">
                                <label>Company</label>
                                <input type="text" placeholder="Enter Company Name Here.." id="company" name="company" class="form-control">
                            </div>  
                        </div>                      
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="text" placeholder="Enter Phone Number Here.." id="ph" name="ph" class="form-control">
                    </div>      
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="text" placeholder="Enter Email Address Here.." id="email" name="email" class="form-control">
                    </div>  
                    <div class="form-group">
                        <label>Website</label>
                        <input type="text" placeholder="Enter Website Name Here.." id="website" name="website" class="form-control">
                    </div>
                    <button type="button" name="sub" id="sub" class="btn btn-lg btn-info">Submit</button>                   
                    </div>
             </form> 


                    </div>
                  <div class="modal-footer">
                 
               <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
            
        </div>
       </div>
        
     </div>

      </body>
<script>
$(document).ready(function($){

  $("#form").validate({
        rules: {
          upload_file:"required",
          name: "required",
            lastname :"required",
             address :"required",
             city:"required",
              state:"required",
              zip:{
                    required:true,
                     minlength:3,
                      maxlength:4,
                 },
              title:"required",
              company:"required",
              ph :{
                    required:true,
                minlength:9,
                maxlength:10,
                },
           website:"required",

            email: {
                required: true,
                 email: true
            },
          


            
        },
        messages: {
          upload_file:"Please upload image",
          name: "Please enter your name",
            lastname:  "Please enter your name",
            address: "Please enter your address",
            city: "Please enter your city",
            state:"Please enter your state",
             
              zip:"Please enter 3 min and max 4 Digit code",
              title:"Please enter your title",
              company:"Please enter your company",
              website:"Please enter your website",
              email: "Please enter a valid email address",
              
               ph: {
                required: "Please provide a Phone Number",
                minlength: "Your password must be at least 10 characters long"
            },
            agree: "Please accept our policy"
        }
    });


    $("#sub").on('click',function(){
      if($("#form").valid())
      {        
                 /*var data = $("#form").serialize();*/
                 var form = $('#form')[0];

                 var data = new FormData(form);
               
                $.ajax
                ({
                   dataType:'json',
                     type: "POST",
                     data: data,
                     url: "ajax.php",  
                     enctype: 'multipart/form-data',
                     processData: false,  // Important!
                     contentType: false,
                     cache: false,        
                   
                      success:function(data) 
                     {
                      
                       alert("success_message");
                        /*  $('#form')[0].reset();*/
                              $('#done').fadeIn('slow',function(){
                             $('#done').delay(3000).fadeOut();
                            });
                          var resd = data.success;
                        $('#done').html('').append(resd).css('color','red');
                    },

                   error:function(data) 
                    {
                     alert("There was an error. Try again please!");

                   }
            });
        

  }
  
    });


});
</script>

</html>
