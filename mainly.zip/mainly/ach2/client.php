

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Plaid Demo Application</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="https://cloud.typography.com/6954312/686646/css/fonts.css"/>
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/8.6/styles/default.min.css">
  <link rel="stylesheet" type="text/css" href="https://demo.plaid.com/styles/style.css">
  <link rel="shortcut icon" href="favicon.ico"/>
  <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/8.6/highlight.min.js"></script>
  <script>hljs.initHighlightingOnLoad();</script>
</head>
<body>


<div class="container">
  <div class="explainer">
    <form class="launchform" id="launchform" action="">
      <div class="toggle product">
        <div class="radiobutton">
          <input type="radio" name="product" id="auth" value="auth" checked>
          <label for="auth"><span></span>Plaid Auth</label>
        </div>
        <div class="radiobutton">
          <input type="radio" name="product" id="connect" value="connect">
          <label for="connect"><span></span>Plaid Connect</label>
        </div>
      </div>

      <div class="toggle mode">
        <div class="radiobutton">
          <input type="radio" name="mode" id="sandbox" value="sandbox" checked>
          <label for="sandbox"><span></span>Sandbox Mode</label>
        </div>
        <div class="radiobutton">
          <input type="radio" name="mode" id="live" value="live"><label for="live">
          <span></span>Live Mode</label>
        </div>
      </div>

      <div class="launchbutton">
        <input type="submit" class="button-primary" id="button" onsubmit="openLink(form)"
               value="Link Account with Plaid">
        <div class="subtext">This will launch Plaid Link.</div>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.plaid.com/link/stable/link-initialize.js"></script>
<script type="text/javascript">
  'use strict';
  var currentlySelectedProduct;
  $(document).ready(function() {
    $('#launchform').on('submit', function(e) {
      e.preventDefault();
      var mode = $('input[name=mode]:checked', this).val();
      var product = $('input[name=product]:checked', this).val();
      currentlySelectedProduct = product;
      // Open Link in the specified mode (sandbox or live) with the specified product (auth or connect).
      handlers[mode][product].open();
    });
    $('#open-code-link').on('click', function(e) {
      e.preventDefault();
      $('#code-section').toggle()
    })
  });
  var createPlaidHandlerForProduct = function(key, product) {
    if (product !== 'connect' && product !== 'auth') {
      throw new Error('Invalid product');
    }
    return Plaid.create({
      clientName: 'Plaid Demo',
      env: 'tartan',
      product: product,
      key: key,
      onSuccess: function(token) {
        window.location = '/accounts.html?public_token=' + token + '&product=' + currentlySelectedProduct;
      },
    });
  };
  var handlers = {
    sandbox: {
      auth: createPlaidHandlerForProduct('test_key', 'auth'),
      connect: createPlaidHandlerForProduct('test_key', 'connect'),
    },
    live: {
      auth: createPlaidHandlerForProduct('76589eeee668a81308beca8d3499d011', 'auth'),
      connect: createPlaidHandlerForProduct('76589eeee668a81308beca8d3499d011', 'connect'),
    },
  };
</script>
</body>
</html>