 <script src="https://cdn.plaid.com/link/stable/link-initialize.js"></script>
    <script>
        var appScheme = 'linkApp';

        var sandboxHandler = Plaid.create({
                                          env: 'tartan',
                                          clientName: 'Client Name',
                                          key: 'test_key',
                                          product: 'auth',
                                          onSuccess: function(public_token) {
                                          var action = 'handlePublicToken';
                                          var url = appScheme + '://' + action + '#' + public_token;
                                          window.location.href = url; // send public_token back to the ViewController delegate
                                          },
                                          onExit: function() {
                                          var action = 'handleOnExit';
                                          var url = appScheme + '://' + action;
                                          window.location.href = url;
                                          },
                                          onLoad: function() {
                                          var action = 'handleOnLoad';
                                          var url = appScheme + '://' + action;
                                          window.location.href = url;
                                          }
                                          });
                                          sandboxHandler.open();

    </script>
