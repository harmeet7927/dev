
<?php include 'config.php';?>
<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
	.loader {
	border: 16px solid #f3f3f3;
	border-radius: 50%;
	border-top: 16px solid #3498db;
	width: 120px;
	height: 120px;
	-webkit-animation: spin 2s linear infinite; /* Safari */
	animation: spin 2s linear infinite;
	}

	/* Safari */
	@-webkit-keyframes spin {
	0% { -webkit-transform: rotate(0deg); }
	100% { -webkit-transform: rotate(360deg); }
	}

	@keyframes spin {
	0% { transform: rotate(0deg); }
	100% { transform: rotate(360deg); }
	}
	</style>
   <body>
	<div class="card-payment">
     <h3>PayPal Pro Integration in PHP</h3>
      <div id="paymentSection">
        <form method="post" id="paymentForm" action="" name ="form">
            <h4>Payable amount: $10 USD</h4>
            <ul>
                <li>
                    <label for="card_number">Card number</label>
                    <input type="text" placeholder="1234 5678 9012 3456" id="card_number" name="card_number">
                </li>
    
                <li class="vertical">
                    <ul>
                        <li>
                            <label for="expiry_month">Expiry month</label>
                            <input type="text" placeholder="MM" maxlength="5" id="expiry_month" name="expiry_month">
                        </li>
                        <li>
                            <label for="expiry_year">Expiry year</label>
                            <input type="text" placeholder="YYYY" maxlength="5" id="expiry_year" name="expiry_year">
                        </li>
                        <li>
                            <label for="cvv">CVV</label>
                            <input type="text" placeholder="123" maxlength="3" id="cvv" name="cvv">
                        </li>
                    </ul>
                </li>
                <li>
                    <label for="name_on_card">Name on card</label>
                    <input type="text" placeholder="Codex World" id="name_on_card" name="name_on_card">
                </li>
                <li>
                    <input type="hidden" name="card_type" id="card_type" value=""/>
                    <div class="loader"  style="display: none;"></div>
                    <input type="submit" name="card_submit" id="cardSubmitBtn" value="Proceed" class="payment-btn"  >
                </li>
            </ul>
        </form>
      </div>

    <div id="orderInfo" style="display: none;"></div>
	</div>
	</body>

	</html>

<?php

if(isset($_POST['card_submit']))
{   
  ?> 
	<script type="text/javascript">$(".loader").style("display","block");</script> 
	  <?php
		// echo $card_number=trim($_POST['card_number'])."<br>";
	     $creditCardNumber = trim(str_replace(" ","",$_POST['card_number']));
		 $expiry_month=trim($_POST['expiry_month']);
		 $expiry_year=trim($_POST['expiry_year']);
		 $plus=trim($expiry_month.$expiry_year)."<br>";
	    
	    $cvv=trim($_POST['cvv'])."<br>";
		$name =trim($_POST['name_on_card']);


	}

    // Set sandbox (test mode) to true/false.
	$sandbox = TRUE;
	 
	// Set PayPal API version and credentials.
	$api_version = '85.0';
	$api_endpoint = $sandbox ? 'https://api-3t.sandbox.paypal.com/nvp' : 'https://api-3t.paypal.com/nvp';
	$api_username = $sandbox ? 'rohit.kumar_api1.mobilyte.com' : 'LIVE_USERNAME_GOES_HERE';
	$api_password = $sandbox ? 'WFJZAJEQBHP24KZU' : 'LIVE_PASSWORD_GOES_HERE';
	$api_signature = $sandbox ? 'AFcWxV21C7fd0v3bYYYRCpSSRl31ApZKO..oB1JNBVGxpN2TtKJnbZmr' : 'LIVE_SIGNATURE_GOES_HERE';

	// Store request params in an array
	$request_params = array(
		'METHOD' => 'DoDirectPayment', 
		'USER' => $api_username, 
		'PWD' => $api_password, 
		'SIGNATURE' => $api_signature, 
		'VERSION' => $api_version, 
		'PAYMENTACTION' => 'Sale',                   
		'IPADDRESS' => $_SERVER['REMOTE_ADDR'],
		'CREDITCARDTYPE' => 'Visa', 
		'ACCT' => $creditCardNumber,                        
		'EXPDATE' =>'112023',           
		'CVV2' => $cvv, 
		'FIRSTNAME' => $name, 
		'LASTNAME' => 'Testerson', 
		'STREET' => '707 W. Bay Drive', 
		'CITY' => 'Largo', 
		'STATE' => 'FL',                     
		'COUNTRYCODE' => 'US', 
		'ZIP' => '33770', 
		'AMT' => '100.00', 
		'CURRENCYCODE' => 'USD', 
		'DESC' => 'Testing Payments Pro'
	);


	// Loop through $request_params array to generate the NVP string.
	$nvp_string = '';
	foreach($request_params as $var=>$val)
	{
	    $nvp_string .= '&'.$var.'='.urlencode($val);    
	}


	        // Send NVP string to PayPal and store response
        	$curl = curl_init();
	        curl_setopt($curl, CURLOPT_VERBOSE, 1);
	        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
	        curl_setopt($curl, CURLOPT_URL, $api_endpoint);
	        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	        curl_setopt($curl, CURLOPT_POSTFIELDS, $nvp_string);
	 
     	    $result = curl_exec($curl);   
     	    echo $result;   
        	curl_close($curl);

			/*echo "<pre>"; print_r($result); echo "</pre>";*/

		    // Parse the API response
		    $nvp_response_array = parse_str($result);


		// Function to convert NTP string to an array
		function NVPToArray($NVPString)
		{
		    $proArray = array();
		    while(strlen($NVPString))
		    {
			        // name
			        $keypos= strpos($NVPString,'=');
			        $keyval = substr($NVPString,0,$keypos);
			        // value
			        $valuepos = strpos($NVPString,'&') ? strpos($NVPString,'&'): strlen($NVPString);
			        $valval = substr($NVPString,$keypos+1,$valuepos-$keypos-1);
			        // decoding the respose
			        $proArray[$keyval] = urldecode($valval);
			        $NVPString = substr($NVPString,$valuepos+1,strlen($NVPString));
		    }
		    /*print_r($proArray);*/
		    return $proArray;
		}
			$proArray=NVPToArray($result);
			$TRANSACTIONID= $proArray['TRANSACTIONID'];
			$ACK= $proArray['ACK'];
			$BUILD= $proArray['BUILD'];
			$AMT= $proArray['AMT'];
			$CURRENCYCODE= $proArray['CURRENCYCODE'];
			$TRANSACTIONID= $proArray['TRANSACTIONID'];

			if($ACK!='Failure')
			{
			  $sql = "INSERT INTO payment (ACK, BUILD,AMT,CURRENCYCODE,TRANSACTIONID)VALUES ('$ACK', '$BUILD', '$AMT','$CURRENCYCODE','$TRANSACTIONID')";

			// echo  $sql;
			$result = mysqli_query($db, $sql);
			    /*$numrows = mysqli_num_rows($result);
			    echo $numrows;*/
			    echo "payment Successfull ";
			}
		else{


			echo "payment Failure";
		}