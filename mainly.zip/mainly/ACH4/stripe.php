<!-- 

\Stripe\Token::create();
\Stripe\Stripe::setApiKey("sk_test_f4L11ATEiU50sHpTKrh8VoUU");

\Stripe\Token::create(array(
  "bank_account" => array(
    "country" => "US",
    "currency" => "usd",
    "account_holder_name" => "Jayden Thomas",
    "account_holder_type" => "individual",
    "routing_number" => "110000000",
    "account_number" => "000123456789"
  )
));



Stripe\Token JSON: {
  "id": "tok_1CaH0tLhBBuSmbSZIsbBwu54",
  "object": "token",
  "card": {
    "id": "card_1CaH0tLhBBuSmbSZ7UXj1syP",
    "object": "card",
    "address_city": null,
    "address_country": null,
    "address_line1": null,
    "address_line1_check": null,
    "address_line2": null,
    "address_state": null,
    "address_zip": null,
    "address_zip_check": null,
    "brand": "Visa",
    "country": "US",
    "cvc_check": null,
    "dynamic_last4": null,
    "exp_month": 8,
    "exp_year": 2019,
    "fingerprint": "dkiJTdYZNpMkMUCG",
    "funding": "credit",
    "last4": "4242",
    "metadata": {
    },
    "name": null,
    "tokenization_method": null
  },
  "client_ip": null,
  "created": 1528350623,
  "livemode": false,
  "type": "card",
  "used": false
} -->

<button id='linkButton'>Open Plaid Link</button>
<script src="https://cdn.plaid.com/link/v2/stable/link-initialize.js"></script>
<script>
var linkHandler = Plaid.create({
  env: 'sandbox',
  clientName: 'Stripe/Plaid Test',
  key: '6de1e1a67b061700620d9549afbb78',
  product: ['auth'],
  selectAccount: true,
  onSuccess: function(public_token, metadata) {
    // Send the public_token and account ID to your app server.
    console.log('public_token: ' + public_token);
    console.log('account ID: ' + metadata.account_id);
  },
  onExit: function(err, metadata) {
    // The user exited the Link flow.
    if (err != null) {
      // The user encountered a Plaid API error prior to exiting.
    }
  },
});

// Trigger the Link UI
document.getElementById('linkButton').onclick = function() {
  linkHandler.open();
};
</script>
<script type="text/javascript">
	
</script>