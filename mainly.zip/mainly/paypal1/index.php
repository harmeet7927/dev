

<?php 

// Set sandbox (test mode) to true/false.
$sandbox = TRUE;
 
// Set PayPal API version and credentials.
$api_version = '85.0';
$api_endpoint = $sandbox ? 'https://api-3t.sandbox.paypal.com/nvp' : 'https://api-3t.paypal.com/nvp';
$api_username = $sandbox ? 'ravikumarlpp_merchant_api1.gmail.com' : 'LIVE_USERNAME_GOES_HERE';
$api_password = $sandbox ? 'S7TXFKFL8M42FLNG' : 'LIVE_PASSWORD_GOES_HERE';
$api_signature = $sandbox ? 'A5BPHh3NfNdj4W2n8abzCdIYlMRbAakL.C8ZfH6pskaN0SnHOnomnFwx' : 'LIVE_SIGNATURE_GOES_HERE';


// Store request params in an array
$request_params = array
                    (
                    'METHOD' => 'DoDirectPayment', 
                    'USER' => $api_username, 
                    'PWD' => $api_password, 
                    'SIGNATURE' => $api_signature, 
                    'VERSION' => $api_version, 
                    'PAYMENTACTION' => 'Sale',                   
                    'IPADDRESS' => $_SERVER['REMOTE_ADDR'],
                    'CREDITCARDTYPE' => 'MasterCard', 
                    'ACCT' => '4111111111111',                        
                    'EXPDATE' => '022022',           
                    'CVV' => '123', 
                    'FIRSTNAME' => 'Tester', 
                    'LASTNAME' => 'Testerson', 
                    'STREET' => '707 W. Bay Drive', 
                    'CITY' => 'Largo', 
                    'STATE' => 'FL',                     
                    'COUNTRYCODE' => 'US', 
                    'ZIP' => '33770', 
                    'AMT' => '100.00', 
                    'CURRENCYCODE' => 'USD', 
                    'DESC' => 'Testing Payments Pro'
                    ); 

                    // Loop through $request_params array to generate the NVP string.
$nvp_string = '';
foreach($request_params as $var=>$val)
{
    $nvp_string .= '&'.$var.'='.urlencode($val);    
}


$ch = curl_init();  
curl_setopt($ch, CURLOPT_URL, $api_endpoint); 
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); 
curl_setopt($ch, CURLOPT_POSTFIELDS, $nvp_string);
$result = curl_exec($ch); 
$resultsArr = explode('&',$result);
$FilterResultsArr = explode('=',$resultsArr[2]);
echo $FilterResultsArr[1].' Results';
curl_close($ch);
echo "<pre>"; print_r($ch); 
echo "<pre>"; print_r($result);

?>

