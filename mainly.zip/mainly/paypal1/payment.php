<?php

// Set sandbox (test mode) to true/false.
$sandbox = TRUE;
 
// Set PayPal API version and credentials.
$api_version = '85.0';
$api_endpoint = $sandbox ? 'https://api-3t.sandbox.paypal.com/nvp' : 'https://api-3t.paypal.com/nvp';
$api_username = $sandbox ? 'rohit.kumar_api1.mobilyte.com' : 'LIVE_USERNAME_GOES_HERE';
$api_password = $sandbox ? 'WFJZAJEQBHP24KZU' : 'LIVE_PASSWORD_GOES_HERE';
$api_signature = $sandbox ? 'AFcWxV21C7fd0v3bYYYRCpSSRl31ApZKO..oB1JNBVGxpN2TtKJnbZmr' : 'LIVE_SIGNATURE_GOES_HERE';

// Store request params in an array
$request_params = array(
	'METHOD' => 'DoDirectPayment', 
	'USER' => $api_username, 
	'PWD' => $api_password, 
	'SIGNATURE' => $api_signature, 
	'VERSION' => $api_version, 
	'PAYMENTACTION' => 'Sale',                   
	'IPADDRESS' => $_SERVER['REMOTE_ADDR'],
	'CREDITCARDTYPE' => 'Visa', 
	'ACCT' => '4111111111111111',                        
	'EXPDATE' => '022023',           
	'CVV2' => '123', 
	'FIRSTNAME' => 'Tester', 
	'LASTNAME' => 'Testerson', 
	'STREET' => '707 W. Bay Drive', 
	'CITY' => 'Largo', 
	'STATE' => 'FL',                     
	'COUNTRYCODE' => 'US', 
	'ZIP' => '33770', 
	'AMT' => '100.00', 
	'CURRENCYCODE' => 'USD', 
	'DESC' => 'Testing Payments Pro'
);

// Loop through $request_params array to generate the NVP string.
$nvp_string = '';
foreach($request_params as $var=>$val)
{
    $nvp_string .= '&'.$var.'='.urlencode($val);    
}


// Send NVP string to PayPal and store response
$curl = curl_init();
        curl_setopt($curl, CURLOPT_VERBOSE, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_TIMEOUT, 30);
        curl_setopt($curl, CURLOPT_URL, $api_endpoint);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $nvp_string);
 
$result = curl_exec($curl);     
curl_close($curl);

echo "<pre>"; print_r($result); echo "</pre>";

// Parse the API response
$nvp_response_array = parse_str($result);

// Function to convert NTP string to an array
function NVPToArray($NVPString)
{
    $proArray = array();
    while(strlen($NVPString))
    {
        // name
        $keypos= strpos($NVPString,'=');
        $keyval = substr($NVPString,0,$keypos);
        // value
        $valuepos = strpos($NVPString,'&') ? strpos($NVPString,'&'): strlen($NVPString);
        $valval = substr($NVPString,$keypos+1,$valuepos-$keypos-1);
        // decoding the respose
        $proArray[$keyval] = urldecode($valval);
        $NVPString = substr($NVPString,$valuepos+1,strlen($NVPString));
    }
    /*print_r($proArray);*/
    return $proArray;
}
$proArray=NVPToArray($result);

echo "<pre>";
print_r($proArray); 
echo "<pre>";

/*echo $proArray['TRANSACTIONID'];*/
?>