<?php 
include "connection.php";
?>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src ="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
<link href="style.css" type="text/css" rel="stylesheet"/>
</head>

<body bgcolor="#BB523F">
  <div id="tabs-container" bgcolor="#BB523F" >
     <ul class="tabs-menu" >
         <li class="current"><a href="#tab-1">Tab 1</a></li>
          <li><a href="#tab-2">Tab 2</a></li>
           <li><a href="#tab-3">Tab 3</a></li>
        <li><a href="#tab-4">Tab 4</a></li>
    </ul>
    
    <br><br><br><br><br>
    

    <div class="tab">
         <div id="tab-1" class="tab-content">
           <form action=" " id="form3" method="post" align="center">
            <div id="div2">
            <h1>Fill basic details</h1>
            <br>        
            <li><input type="text" id="name3" name="name3" placeholder="Name" ></li>
            <li><input type="text" id="email3" name="email3" placeholder=" email address"></li>
            <li><input type="ph" id="tel" name="ph" placeholder="Ph.no3"></li>
             <li><input type="submit" name="subconatct" id="subconatct" value="submit"></li>
        </div>
    </form>
        </div>

         
    <div id="tab-2" class="tab-content" align="center">
         <form action=" " id="form2" method="post">
            <div id="div2">
             <h1>Input address details</h1>
             <br>        
             <li><input type="text" id="address" name="address" placeholder="address" ></li>
           
             <li><input type="ph" id="pin" name="pin" placeholder="Pin no"></li>
             <li><input type="submit" name="subconatct1" id="subconatct1" value="submit"></li>
        </div>
    </form>
        </div>

        <div id="tab-3" class="tab-content"  align="center">
         <form action=" " id="form1" method="post">
            <div id="div2">
            <h1>About Hobbies</h1>
            <br>        
         <li><input type="text" id="hobbies1" name="hobbies1" placeholder="hobbies1" ></li>  <li><input type="text" id="hobbies2" name="hobbies2" placeholder="hobbies2" ></li>
          <li><input type="submit" name="subconatct4" id="subconatct4" value="submit"></li>
        </div>
        </form>
    </div>


        
     <div id="tab-4" class="tab-content">
     <form action=" " id="form1" method="post">
        <div id="div2">
            <h1 align="center"> Finshed </h1>
            <br>        
         <li align="center"> Thanks for form submit Data</li>           
        </div>
    </form>
 </div>


    </div>
</div>
 

 
</body>
<!--  script section start -->
<script>
$(document).ready(function(){
    $("#subconatct").on('click',function()
    { 

        // e.preventDefault();
         alert('data send successfully');    
    var data1 = $("#form3").serialize();
     
      $.ajax(
   {

         dataType:'json',
         type: "POST",
         data: data1,
         url: "ajax1.php",          
         async: false,
        
    });

});




    });


</script>
</html>