<?php
//include "connection.php";
require('connection.php');



if(isset($_POST['email3'])) 
{
  $name3 =$_POST['name3'];
  $email3 =$_POST['email3'];
  $contact=$_POST['ph'];


$sql = "UPDATE contact SET name='$name3',email='$email3',contact='$contact' WHERE id=1";
  
  if(mysqli_query($conn,$sql))

 {
    
   $return_data[" su"] = "done";
     
    echo json_encode($return_data);
 }
 else{

   $return_data["error_insert"] = "error_insert ";
    echo json_encode($return_data);
 }


 }
 ?>

