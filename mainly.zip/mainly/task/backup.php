<?php

//include "connection.php";
require('connection.php');

//  contact form start

if(isset($_POST['email3'])) 
{
  $name3 =$_POST['name3'];
  $email3 =$_POST['email3'];
  $contact=$_POST['ph'];
  //echo "$name3";
  //echo "hello";
  // echo "$ph";

$sql = "INSERT INTO contact(name,email,contact)VALUES('".$name3."','".$email3."','".$contact."')";
  //print_r($sql);
  //$result = mysqli_query($conn,$sql);
    //if($result)
  if(mysqli_query($conn,$sql))
 {
    
   $return_data[" su"] = " Data inserted successfully ";
       echo json_encode($return_data);

 }
 else{

   $return_data["error_insert"] = "error_insert ";
   echo json_encode($return_data);
 }


 }

 // conatct form End
if(isset($_POST['address'])) 
{
  $address =$_POST['address'];
  $pin =$_POST['pin'];
 
  
$sql = "INSERT INTO address(address,pin)VALUES('".$address."','".$pin."')";
  //print_r($sql);
  //$result = mysqli_query($conn,$sql);
    //if($result)
  if(mysqli_query($conn,$sql))
 {
    
   $return_data[" su"] = " Data inserted successfully ";
       echo json_encode($return_data);

 }
 else{

   $return_data["error_insert"] = "error_insert ";
   echo json_encode($return_data);
 }

 
 }
// conatct form End

 //hobbies section start
if(isset($_POST['hobbies1'])) 
{
  $hobbies1 =$_POST['hobbies1'];
  $hobbies2 =$_POST['hobbies2'];
 
  
$sql = "INSERT INTO hobbies(hobbies1,hobbies2)VALUES('".$hobbies1."','".$hobbies2."')";
  //print_r($sql);
  //$result = mysqli_query($conn,$sql);
    //if($result)
  if(mysqli_query($conn,$sql))
 {
    
   $return_data[" su"] = " Data inserted successfully ";
       echo json_encode($return_data);

 }
 else{

   $return_data["error_insert"] = "error_insert ";
   echo json_encode($return_data);
 }

 
 }

 //hobbies section End

 ?>