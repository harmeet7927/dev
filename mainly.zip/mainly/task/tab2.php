<?php set_include_path($_SERVER['DOCUMENT_ROOT']); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    
    <title>jQuery UI Tabs with Next/Previous</title>

    <link rel="stylesheet" href="tabs.css" type="text/css" media="screen, projection"/>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src ="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui-1.7.custom.min.js"></script>
    <script type="text/javascript">
        $(function() {

            var $tabs = $('#tabs').tabs();
    
            $(".ui-tabs-panel").each(function(i){
    
              var totalSize = $(".ui-tabs-panel").size() - 1;
    
              if (i != totalSize) {
                  next = i + 2;
                  $(this).append("<a href='#' class='next-tab mover' rel='" + next + "'>Next Page &#187;</a>");
              }

            
     
      
              if (i != 0) {
                  prev = i;
                  $(this).append("<a href='#' class='prev-tab mover' rel='" + prev + "'>&#171; Prev Page</a>");
              }
        
            });
    
            $('.next-tab, .prev-tab').click(function() { 
                   $tabs.tabs('select', $(this).attr("rel"));
                   return false;
               });
       

        });

    </script>

</head>

<body>

    <div id="page-wrap">
        
        <div id="tabs">
        
            <ul>
                <li><a href="#fragment-1">1</a></li>
                <li><a href="#fragment-2">2</a></li>
                <li><a href="#fragment-3">3</a></li>
                <li><a href="#fragment-4">4</a></li>
                
           </ul>
    
            <div id="fragment-1" class="ui-tabs-panel">
           <form action="" id="form3" method="post" align="center">
       
            <h1>Fill basic details</h1>
            <br>        
            <li><input type="text" id="name3" name="name3" placeholder="Name"></li>
            <li><input type="text" id="email3" name="email3" placeholder=" email address"></li>
            <li><input type="ph" id="tel" name="ph" placeholder="Ph.no3"></li>
             <li><input type="submit" name="subconatct" id="subconatct" value="submit"></li>
       
    </form>
            </div>
            
            <div id="fragment-2" class="ui-tabs-panel ui-tabs-hide">
                    <p>Donec ultricies senectus tristique egestas vitae, et ac morbi habitant quam sit mi quam, malesuada leo. Vestibulum tempor Mauris tortor libero eget, egestas. eu vitae feugiat netus amet Pellentesque ante. amet, ultricies eleifend turpis sit placerat et semper. Aenean est. fames </p>
            </div>
            
            <div id="fragment-3" class="ui-tabs-panel ui-tabs-hide">
                    <p>ante. Mauris Vestibulum est. fames egestas quam, leo. amet tristique sit libero egestas. ultricies mi turpis senectus Pellentesque habitant eu ac morbi netus eget, Aenean malesuada vitae, semper. eleifend et feugiat vitae amet, placerat Donec et tortor ultricies tempor quam sit </p>
            </div>
        
            <div id="fragment-4" class="ui-tabs-panel ui-tabs-hide">

            </div>
            
        </div>
        
    </div>
    
</body>
<script type="text/javascript">
    
             $(document).ready(function(){
                    $("#subconatct").on('click',function()
                    { 

                        // e.preventDefault();
                         alert('data send successfully');    
                    var data1 = $("#form3").serialize();
                     alert("hello1");
                      $.ajax(
                   {

                         dataType:'json',
                         type: "POST",
                         data: data1,
                         url: "ajax1.php",          
                         async: false,
                        
                    });

                });




                    });
           

        
</script>

</html>
