<?php

//include "connection.php";
require('connection.php');

//  contact form start

if(isset($_Get['fname'])) 
{
  $fname =$_Get['fname'];
  $lname =$_Get['lname'];
  $email =$_Get['email'];
  $phone=$_Get['phone'];

  $dd =$_Get['dd'];
  $nn =$_Get['nn'];
  $yyyy=$_Get['yyyy'];

   $uname =$_Get['uname'];
    $pword =$_Get['pword'];
 
  //echo "$name3";
   alert("hello");
   echo"hello";
    echo $fname;
 }

 // conatct form End
 ?>