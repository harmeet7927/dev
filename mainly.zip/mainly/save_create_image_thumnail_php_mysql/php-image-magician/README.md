php-image-magician
=====================

Image manipulation at it's finest.
