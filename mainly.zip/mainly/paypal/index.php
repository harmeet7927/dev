<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script type="text/javascript" src="jquery.creditCardValidator.js"></script>
</head>
<body>
<div class="card-payment">
    <h3>PayPal Pro Integration in PHP</h3>
    <div id="paymentSection">
        <form method="post" id="paymentForm">
            <h4>Payable amount: $10 USD</h4>
            <ul>
                <li>
                    <label for="card_number">Card number</label>
                    <input type="text" placeholder="1234 5678 9012 3456" id="card_number" name="card_number">
                </li>
    
                <li class="vertical">
                    <ul>
                        <li>
                            <label for="expiry_month">Expiry month</label>
                            <input type="text" placeholder="MM" maxlength="5" id="expiry_month" name="expiry_month">
                        </li>
                        <li>
                            <label for="expiry_year">Expiry year</label>
                            <input type="text" placeholder="YYYY" maxlength="5" id="expiry_year" name="expiry_year">
                        </li>
                        <li>
                            <label for="cvv">CVV</label>
                            <input type="text" placeholder="123" maxlength="3" id="cvv" name="cvv">
                        </li>
                    </ul>
                </li>
                <li>
                    <label for="name_on_card">Name on card</label>
                    <input type="text" placeholder="Codex World" id="name_on_card" name="name_on_card">
                </li>
                <li>
                    <input type="hidden" name="card_type" id="card_type" value=""/>
                    <input type="button" name="card_submit" id="cardSubmitBtn" value="Proceed" class="payment-btn" disabled="true" >
                </li>
            </ul>
        </form>
    </div>
    <div id="orderInfo" style="display: none;"></div>
</div>
</body>
<script type="text/javascript">
	<script>
function cardFormValidate(){
    var cardValid = 0;

    //card number validation
    $('#card_number').validateCreditCard(function(result){
        if(result.valid){
            $("#card_number").removeClass('required');
            cardValid = 1;
        }else{
            $("#card_number").addClass('required');
            cardValid = 0;
        }
    });
      
    //card details validation
    var cardName = $("#name_on_card").val();
    var expMonth = $("#expiry_month").val();
    var expYear = $("#expiry_year").val();
    var cvv = $("#cvv").val();
    var regName = /^[a-z ,.'-]+$/i;
    var regMonth = /^01|02|03|04|05|06|07|08|09|10|11|12$/;
    var regYear = /^2017|2018|2019|2020|2021|2022|2023|2024|2025|2026|2027|2028|2029|2030|2031$/;
    var regCVV = /^[0-9]{3,3}$/;
    if (cardValid == 0) {
        $("#card_number").addClass('required');
        $("#card_number").focus();
        return false;
    }else if (!regMonth.test(expMonth)) {
        $("#card_number").removeClass('required');
        $("#expiry_month").addClass('required');
        $("#expiry_month").focus();
        return false;
    }else if (!regYear.test(expYear)) {
        $("#card_number").removeClass('required');
        $("#expiry_month").removeClass('required');
        $("#expiry_year").addClass('required');
        $("#expiry_year").focus();
        return false;
    }else if (!regCVV.test(cvv)) {
        $("#card_number").removeClass('required');
        $("#expiry_month").removeClass('required');
        $("#expiry_year").removeClass('required');
        $("#cvv").addClass('required');
        $("#cvv").focus();
        return false;
    }else if (!regName.test(cardName)) {
        $("#card_number").removeClass('required');
        $("#expiry_month").removeClass('required');
        $("#expiry_year").removeClass('required');
        $("#cvv").removeClass('required');
        $("#name_on_card").addClass('required');
        $("#name_on_card").focus();
        return false;
    }else{
        $("#card_number").removeClass('required');
        $("#expiry_month").removeClass('required');
        $("#expiry_year").removeClass('required');
        $("#cvv").removeClass('required');
        $("#name_on_card").removeClass('required');
        return true;
    }
}
$(document).ready(function() {
    //card validation on input fields
    $('#paymentForm input[type=text]').on('keyup',function(){
        cardFormValidate();
    });
});
</script>
</script>
</html>