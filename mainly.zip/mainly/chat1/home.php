	<?php
	   include "connection.php";
	   session_start();
    ?>
	<html>
	<head>
		<title>Simple Chat Room</title>
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,400,300' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/style.css" />
		<script type="text/javascript" src="js/jquery-1.10.2.min.js" ></script>
	</head>
	<body>
	
		<div class='header'>
			 <h1>
				Welcome User <?php echo  $_SESSION['id'];  ?>
				<?php if(isset($_SESSION['id'])) 
				{ ?>
				<p><a href="trash.php"  class='logout' >TRASH Messages</a></p>!
				<p><a href="sendmessage.php" class='logout'>Send messages</a>!</p>
				<a class='logout' href="logout.php">Logout</a></button></p>

				<?php } ?>
			 </h1>
		</div>
       
		
		<!-- FETCH DATA FROM DB START -->	
    <div id="div1" align="center">
   	<h1>Received messages</h1>
       <table class="table table-hover">
    <thead>
    <tr>
         <th>ID</th>
          <th>sender</th>
           <th>receiver</th>
           <th>message</th>
           <th>status</th>
          <th>Action</th> 
          <th>Action</th>  
         </tr>
  </thead>
   <tbody>
   <?php
         $id=$_SESSION['id'];
         /*  $sql = "SELECT * FROM table2  where receiver_id='$id' AND receiver_status='1'";*/
         $receiver_id=$id;
         $array = array();
    $sql = "SELECT * FROM table2  where receiver_id= '$receiver_id' AND receiver_status='1'";

          $result=mysqli_query($conn,$sql);
           $rowcount=mysqli_num_rows($result);

            while ($data=mysqli_fetch_assoc($result))
		    {         
		    	$array =$data;
		    	
		       
		        ?>
		    	

		         <tr>
        	<td><?php echo $data['id'] ;?></td>
           	<td><?php echo $data["receiver_id"];?></td>
        	<td><?php echo $data['sender_id'] ;?></td>
        	<td><?php echo $data["message"] ;?></td>
        	<td><?php echo $data["sender_status"] ;?></td>
        	<!-- <td><?php echo $data["message"] ;?></td> -->
            <td><a href="#" data-toggle="modal" data-target="#myModal5" class="viewdata" id="<?php echo $data['id']; ?>">view</a></td>
           
             <td><button class="delete" name="delete" id="<?php echo $data['id']; ?>" value="delete">delete</button> </td>
        </tr>
		 <?php   }  
    	?>

      </tbody>

      </table>
  </div>
    <!-- FETCH DATA FROM DB END -->
 
     <div id="option_id" align="center"></div>


	 <div class='chatcontrols' id='option_id' align="center" margin-bottom="10px;" >
	 	<p  id="contact">contact_List</p>
	  <form method="post" id='form' action="">

	  	   <select name="id"  onChange="getid(this.value)">
		    <option value="" name="selected" selected="selected"></option>

		    <?php 
		       $query = "SELECT * FROM table1"; 
		          $result = mysqli_query($conn,$query); 
		           while ($row = $result->fetch_assoc())   
			        {                              
			       	    $id = $row['id'];
			            $name = $row['name']; 
			           echo "<option value='$id'>"  .$name. "</option>";
				    }  
		           ?>

		</select>
	  	<!--  <input type="hidden" id="option_id"  name="ss">  -->
	  	
		<input type='text' name='chat' id='chatbox' autocomplete="off" placeholder="ENTER CHAT HERE" />
		<input type='submit' name='send' id='send' class='btn btn-send' value='Send' />
		</form>
  </div>


</body>
      <script type="text/javascript">
   	   function getid(value)
    	 {   
			    var data=+value;     /*Script for images start*/
		      if(+value)
			   {			   

			      document.getElementById('option_id').innerHTML = data;
			      $("option_id").html("").append(data);
			   }
		}
	   </script>
	   
	   

	   </script>
	   <script type="text/javascript">
	   	$(document).ready(function()
	   	{
		   $('#form').on('submit',function(e)
		{
		e.preventDefault();
		alert("djd");
		var datastring = $("#form").serialize();
		
		$.ajax({
			datatype:"json",
			type:'POST',
			data: datastring,
			url:'ajax.php',
			// success section start
			success:function(data)
			{
				/*var output=data.btn;
				$('#result').html('').append(data.success);
				document.getElementById('#form').rest();*/		
			}
	  	});
	  });
	
	//Delete Data coding
  $('.delete').on('click',function(e){ 
      e.preventDefault();
   
      var delete1 = 'delete';
       var id =$(this).attr('id');
       var datastring = 'delete='+delete1+'&id='+id;
      $.ajax({

       dataType: 'json',
       type: 'POST',
       data: datastring,
       url: 'ajax1.php',
     success: function(data){
    alert('data delete successfully');    
  }
  });
  });
//End delete Coding 

	

	});	
		
	   </script>
	  
</html>