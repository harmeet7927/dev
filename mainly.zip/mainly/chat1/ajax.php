<?php
include "connection.php";
  session_start();
if(isset($_POST['chat']))
{
   echo $message=$_POST['chat'];
   echo $login_id= $_SESSION['id'];
   echo $receiver_id=$_POST['id'];

    $sender_status="1";
    $receiver_status="1"; 
    $sender_flag="0";
    $receiver_flag="0";

    $sql="INSERT INTO table2 (sender_id,receiver_id,message, sender_status,receiver_status,sender_flag,receiver_flag)VALUES ('$login_id','$receiver_id','$message','$sender_status','$receiver_status',$sender_flag,$receiver_flag)";

     
/*
       $result=mysqli_query($conn,$sql); 
    echo "<pre>"; print_r($result); die("hhh"); 
*/
    if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
  }
?>