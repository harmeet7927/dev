	<?php
	session_start();
	include "connection.php";
	if(isset($_POST['delete']))
	{
	     $receiver_status='0';
          $id=$_POST['id'];
           $sql="UPDATE table2 SET receiver_status = '$receiver_status' WHERE id = '$id'";
         $result=mysqli_query($conn,$sql);
         if($result)
         { 
         	$sender_flag='1';
         	$sql="UPDATE table2 SET sender_flag = '$sender_flag' WHERE id = '$id'";
            $result=mysqli_query($conn,$sql);
         	echo"1";
         }
    
    }
    if(isset($_POST['senddelete']))
	{
	 echo $sender_status='0';
      $id=$_POST['id'];
     //echo $id=$_SESSION['id'];
     /* $sql="INSERT INTO table2 (receiver_id,receiver_status)VALUES ('$receiver_id','$receiver_status')";*/
     $sql="UPDATE table2 SET sender_status = '$sender_status' WHERE id = '$id'";
       $result=mysqli_query($conn,$sql);
    
    }
   //Trash code start 
    if(isset($_POST['deletetrash']))
	{
	 echo $sender_flag='0';
     echo $id=$_POST['id'];
     //echo $id=$_SESSION['id'];
     /* $sql="INSERT INTO table2 (receiver_id,receiver_status)VALUES ('$receiver_id','$receiver_status')";*/
     $sql="UPDATE table2 SET sender_flag = '$sender_flag' WHERE id = '$id'";
       $result=mysqli_query($conn,$sql);
    
    }
    //treash Code End here


	?>