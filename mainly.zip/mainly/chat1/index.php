<?php 
    include "connection.php";
    session_start();
	if(isset($_POST['sub']))
	{
		
       echo $name=$_POST['name'];
        $sql= "SELECT * FROM table1 WHERE name='$name'";
        $result =mysqli_query($conn,$sql);
        $data=mysqli_fetch_assoc($result);
        if($result->num_rows > 0)
        {
        	/*echo"<pre>"; print_r($data); echo"</pre>";*/
            $id= $data['id'];
            $_SESSION['id']=$id;
            header('Location: home.php');

        }
       else
        {          
           $sql = "INSERT INTO table1 (name)VALUES ('$name')";
           $result=mysqli_query($conn,$sql);
        if($result)
           {

          	$last_id = mysqli_insert_id($conn);
            $_SESSION['id']=$last_id;
            header('Location: home.php');
           }

        }
	}
?>
<html>
<head>
	<title>Simple Chat Room</title>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,400,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css" />
	<script type="text/javascript" src="js/jquery-1.10.2.min.js" ></script>
</head>
<body>
<div class='userscreen'>
	<form method="POST" action=" " >
		<input type='text'  name="name" class='input-user' placeholder="ENTER YOUR NAME HERE" name='username' />
		<input type='submit' name="sub" class='btn btn-user' value='START CHAT' />
	</form>
</div>

</body>
</html>