	<?php
	   include "connection.php";
	   session_start();
    ?>
	<html>
	<head>
		<title>Simple Chat Room</title>
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,400,300' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="css/style.css" />
		<script type="text/javascript" src="js/jquery-1.10.2.min.js" ></script>
	</head>
	<body>
	
		<div class='header'>
			 <h1>
				Welcome User <?php echo  $_SESSION['id'];  ?>
				<?php if(isset($_SESSION['id'])) 
				{ ?>
				<p><a href="home.php"  class='logout' >Receive mails </a></p>!
				<p><a href="sendmessage.php" class='logout'>Send messages</a>!</p>
				<a class='logout' href="logout.php">Logout</a></button></p>

				<?php } ?>
			 </h1>
		</div>
       
		
		<!-- FETCH DATA FROM DB START -->	
   <div id="div1" align="center">
   		<h1>Trash messages</h1>
       <table class="table table-hover">
    <thead>
    <tr>
         <th>ID</th>
          <th>sender</th>
           <th>receiver</th>
           <th>message</th>
           <th>status</th>
          <th>Action</th> 
          <th>Action</th>  
         </tr>
  </thead>
   <tbody>
   <?php
         $id=$_SESSION['id'];
         $receiver_id=$id;
         $array = array();
         $sql = "SELECT * FROM table2  where receiver_id= $receiver_id AND sender_flag='1'";
          $result=mysqli_query($conn,$sql);
           $rowcount=mysqli_num_rows($result);
            while ($data=mysqli_fetch_assoc($result))
		    {         
		    	$array =$data;
		       
		        ?>
	        <tr>
        	<td><?php echo $data['id'] ;?></td>
           	<td><?php echo $data["receiver_id"];?></td>
        	<td><?php echo $data['sender_id'] ;?></td>
        	<td><?php echo $data["message"] ;?></td>
        	<td><?php echo $data["sender_status"] ;?></td>	                 
             <td><button class="delete" name="delete" id="<?php echo $data['id']; ?>" value="delete">delete</button> </td>
        </tr>
		 <?php   }  
    	?>

      </tbody>

      </table>
  </div>
    <!-- FETCH DATA FROM DB END -->
 
     <div id="option_id" align="center"></div>
 
</body>
<script type="text/javascript">
	$(document).ready(function(){
	  $('.delete').on('click',function(e){ 
      e.preventDefault();
   
      var deletetrash = 'delete';
       var id =$(this).attr('id');
       var datastring = 'deletetrash='+deletetrash+'&id='+id;
      $.ajax({

       dataType: 'json',
       type: 'POST',
       data: datastring,
       url: 'ajax1.php',
     success: function(data){
    alert('data delete successfully');    
  }
  });
  });
	   });
</script>  
</html>