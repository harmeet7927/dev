
<?php
// Stripe library
require 'stripe/lib/Stripe.php';
 
$params = array(
	"testmode"   => "on",
	
	"private_test_key" => "sk_test_f4L11ATEiU50sHpTKrh8VoUU",
	"public_test_key"  => "pk_test_U1VplD3IcTHSWUtKmfwO8RS8"
);
 
 $on=$params['testmode'];
if ($on == "on") {
	echo "tt";
	Stripe::setApiKey($params['private_test_key']);
	$pubkey = $params['public_test_key'];
} 
 
if(isset($_POST['stripeToken']))
{  
	echo "dd";
	$amount_cents = str_replace(".","","10.52");  // Chargeble amount
	$invoiceid = "14526321";                      // Invoice ID
	$description = "Invoice #" . $invoiceid . " - " . $invoiceid;
	
	try {
 
		$charge = Stripe_Charge::create(array(		 
			  "amount" => $amount_cents,
			  "currency" => "usd",
			  "source" => $_POST['stripeToken'],
			  "description" => $description)			  
		);
 
		if ($charge->card->address_zip_check == "fail") {
			throw new Exception("zip_check_invalid");
		} else if ($charge->card->address_line1_check == "fail") {
			throw new Exception("address_check_invalid");
		} else if ($charge->card->cvc_check == "fail") {
			throw new Exception("cvc_check_invalid");
		}
		// Payment has succeeded, no exceptions were thrown or otherwise caught				
 
		$result = "success";
 
	} catch(Stripe_CardError $e) {			
 
	$error = $e->getMessage();
		$result = "declined";
 
	} catch (Stripe_InvalidRequestError $e) {
		$result = "declined";		  
	} catch (Stripe_AuthenticationError $e) {
		$result = "declined";
	} catch (Stripe_ApiConnectionError $e) {
		$result = "declined";
	} catch (Stripe_Error $e) {
		$result = "declined";
	} catch (Exception $e) {
 
		if ($e->getMessage() == "zip_check_invalid") {
			$result = "declined";
		} else if ($e->getMessage() == "address_check_invalid") {
			$result = "declined";
		} else if ($e->getMessage() == "cvc_check_invalid") {
			$result = "declined";
		} else {
			$result = "declined";
		}		  
	}
	
	echo "<BR>Stripe Payment Status : ".$result;
	
	echo "<BR>Stripe Response : ";
	
	print_r($charge); exit;
}
?>